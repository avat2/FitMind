const mongoose = require('mongoose');

const progressSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'User' },
    planId: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'Plan' },
    date: { type: Date, required: true },
    progress: { type: String, required: true },
});

const Progress = mongoose.model('Progress', progressSchema);

module.exports = Progress;
