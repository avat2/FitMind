const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/fitmind', { useNewUrlParser: true, useUnifiedTopology: true });

const User = mongoose.model('User', new mongoose.Schema({
    username: String,
    email: String,
    password: String,
}));

const Plan = mongoose.model('Plan', new mongoose.Schema({
    userId: mongoose.Schema.Types.ObjectId,
    type: String, // 'workout' or 'meditation'
    name: String,
    duration: Number, // in minutes
    details: String,
}));

const Progress = mongoose.model('Progress', new mongoose.Schema({
    userId: mongoose.Schema.Types.ObjectId,
    planId: mongoose.Schema.Types.ObjectId,
    date: Date,
    progress: String,
}));

app.post('/register', async (req, res) => {
    const { username, email, password } = req.body;
    const user = new User({ username, email, password });
    await user.save();
    res.send('User registered');
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email, password });
    if (user) {
        res.send('Login successful');
    } else {
        res.send('Invalid credentials');
    }
});

app.post('/plans', async (req, res) => {
    const { userId, type, name, duration, details } = req.body;
    const plan = new Plan({ userId, type, name, duration, details });
    await plan.save();
    res.send('Plan created');
});

app.get('/plans/:userId', async (req, res) => {
    const { userId } = req.params;
    const plans = await Plan.find({ userId });
    res.send(plans);
});

app.post('/progress', async (req, res) => {
    const { userId, planId, date, progress } = req.body;
    const prog = new Progress({ userId, planId, date, progress });
    await prog.save();
    res.send('Progress recorded');
});

app.get('/progress/:userId', async (req, res) => {
    const { userId } = req.params;
    const progress = await Progress.find({ userId });
    res.send(progress);
});

app.listen(
